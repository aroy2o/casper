import './assets/service-worker.ts-BK63RTDb.js';
