(function(){const h=["tender","bid","procurement","NIT","RFP","EOI","BOQ","bill of quantities","e-procurement","eprocure","GeM","works contract","rate contract","supply order","quotation"],m={low:"#22c55e",medium:"#f59e0b",high:"#f97316",critical:"#ef4444"},k={low:"#dcfce7",medium:"#fef3c7",high:"#ffedd5",critical:"#fee2e2"};function w(){const t=(document.title+" "+document.body.innerText.slice(0,3e3)).toLowerCase();return h.some(e=>t.includes(e.toLowerCase()))}function z(){const t=["main","article","#content",".content","#main",".main-content","body"];for(const e of t){const i=document.querySelector(e);if(i)return i.innerText.slice(0,25e3)}return document.body.innerText.slice(0,25e3)}let n=null,a=!1,d=!1;function S(){const t=document.createElement("div");return t.id="casper-panel",Object.assign(t.style,{position:"fixed",bottom:"80px",right:"16px",width:"360px",maxHeight:"80vh",overflowY:"auto",background:"#0f172a",color:"#e2e8f0",borderRadius:"16px",boxShadow:"0 20px 60px rgba(0,0,0,0.5)",fontFamily:"'Inter', system-ui, sans-serif",fontSize:"13px",zIndex:"2147483646",border:"1px solid #1e3a5f",display:"none"}),t}function R(t){t.innerHTML=`
    <div style="padding:20px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <span style="font-size:18px;font-weight:700;color:#38bdf8;">CASPER</span>
        <span style="font-size:11px;color:#64748b;margin-left:auto;">Analyzing tender...</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px;color:#64748b;">
        <div style="width:16px;height:16px;border:2px solid #38bdf8;border-top-color:transparent;border-radius:50%;animation:casper-spin 0.8s linear infinite;flex-shrink:0;"></div>
        <span>Running ML audit on page content...</span>
      </div>
    </div>
    <style>
      @keyframes casper-spin { to { transform: rotate(360deg); } }
      #casper-panel::-webkit-scrollbar { width:6px; }
      #casper-panel::-webkit-scrollbar-track { background:#1e293b; }
      #casper-panel::-webkit-scrollbar-thumb { background:#334155;border-radius:3px; }
    </style>
  `}function g(t,e){var i;t.innerHTML=`
    <div style="padding:20px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <span style="font-size:18px;font-weight:700;color:#38bdf8;">CASPER</span>
      </div>
      <div style="background:#450a0a;border:1px solid #7f1d1d;border-radius:10px;padding:12px;color:#fca5a5;font-size:12px;">
        ${o(e)}
      </div>
      <button id="casper-retry" style="margin-top:12px;width:100%;padding:8px;background:#1e3a5f;color:#38bdf8;border:1px solid #1e4a6e;border-radius:8px;cursor:pointer;font-size:12px;">
        Retry
      </button>
    </div>
  `,(i=t.querySelector("#casper-retry"))==null||i.addEventListener("click",()=>p())}function o(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function s(t){return t>=1e7?`₹${(t/1e7).toFixed(2)} Cr`:t>=1e5?`₹${(t/1e5).toFixed(2)} L`:`₹${t.toLocaleString("en-IN")}`}function $(t,e){var c,x,f;const i=m[e.riskLevel]??"#64748b",u=k[e.riskLevel]??"#1e293b",y=e.flags.slice(0,5).map(r=>`
    <div style="background:#1e293b;border-radius:8px;padding:10px;margin-bottom:8px;border-left:3px solid #ef4444;">
      <div style="font-weight:600;margin-bottom:4px;font-size:12px;">${o(r.lineItemDescription.slice(0,80))}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:11px;color:#94a3b8;">
        <span>Quoted: <b style="color:#fca5a5;">${s(r.quotedRateINR)}</b></span>
        <span>Market: <b style="color:#86efac;">${s(r.marketRateINR)}</b></span>
        <span>+${Math.round(r.inflationPct)}% inflation</span>
      </div>
      <div style="margin-top:4px;font-size:11px;color:#64748b;">${o(r.explanation.slice(0,120))}</div>
    </div>
  `).join(""),v=e.riskSignals.slice(0,4).map(r=>`
    <div style="display:flex;align-items:start;gap:6px;margin-bottom:4px;">
      <span style="color:#f97316;flex-shrink:0;">⚠</span>
      <span style="font-size:11px;color:#94a3b8;">${o(r)}</span>
    </div>
  `).join("");t.innerHTML=`
    <style>
      #casper-panel::-webkit-scrollbar { width:6px; }
      #casper-panel::-webkit-scrollbar-track { background:#1e293b; }
      #casper-panel::-webkit-scrollbar-thumb { background:#334155;border-radius:3px; }
      .casper-btn { cursor:pointer; transition: opacity 0.15s; }
      .casper-btn:hover { opacity:0.85; }
    </style>
    <div style="padding:16px 20px;">
      <!-- Header -->
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;">
        <span style="font-size:16px;font-weight:700;color:#38bdf8;letter-spacing:-0.5px;">CASPER</span>
        <span style="font-size:10px;color:#475569;margin-left:auto;">
          ${new Date(e.auditedAt).toLocaleTimeString("en-IN")}
        </span>
        <button id="casper-close-panel" class="casper-btn" style="background:none;border:none;color:#64748b;font-size:16px;padding:2px 4px;">✕</button>
      </div>

      <!-- Risk Badge -->
      <div style="display:flex;align-items:center;gap:10px;background:${u};border-radius:10px;padding:12px 14px;margin-bottom:14px;">
        <div style="width:10px;height:10px;border-radius:50%;background:${i};flex-shrink:0;box-shadow:0 0 8px ${i};"></div>
        <div>
          <div style="font-weight:700;color:${i};font-size:14px;text-transform:uppercase;">
            ${e.riskLevel} RISK
          </div>
          ${e.tenderNumber?`<div style="font-size:11px;color:#64748b;margin-top:2px;">Tender: ${o(e.tenderNumber)}</div>`:""}
        </div>
        <div style="margin-left:auto;text-align:right;">
          ${e.overallInflationPct>0?`<div style="font-size:18px;font-weight:700;color:#fca5a5;">+${e.overallInflationPct}%</div>
          <div style="font-size:10px;color:#64748b;">avg inflation</div>`:""}
        </div>
      </div>

      <!-- Stats row -->
      ${e.flags.length>0||e.totalOverpricedINR>0?`
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
        <div style="background:#1e293b;border-radius:8px;padding:10px;text-align:center;">
          <div style="font-size:20px;font-weight:700;color:#ef4444;">${e.flags.length}</div>
          <div style="font-size:10px;color:#64748b;">Flagged Items</div>
        </div>
        <div style="background:#1e293b;border-radius:8px;padding:10px;text-align:center;">
          <div style="font-size:14px;font-weight:700;color:#fca5a5;">${e.totalOverpricedINR>0?s(e.totalOverpricedINR):"—"}</div>
          <div style="font-size:10px;color:#64748b;">Overpriced Amt</div>
        </div>
      </div>`:""}

      <!-- Verdict -->
      ${e.claudeVerdict?`
      <div style="margin-bottom:12px;">
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#475569;margin-bottom:4px;letter-spacing:0.05em;">ML Verdict</div>
        <div style="background:#1e293b;border-radius:8px;padding:8px 12px;font-size:12px;color:#94a3b8;font-style:italic;">
          ${o(e.claudeVerdict)}
        </div>
      </div>`:""}

      <!-- Summary -->
      ${e.summary?`
      <div style="margin-bottom:12px;">
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#475569;margin-bottom:4px;letter-spacing:0.05em;">Summary</div>
        <div style="background:#1e293b;border-radius:8px;padding:8px 12px;font-size:12px;color:#94a3b8;line-height:1.5;">
          ${o(e.summary.slice(0,400))}
        </div>
      </div>`:""}

      <!-- Flags -->
      ${e.flags.length>0?`
      <div style="margin-bottom:12px;">
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#475569;margin-bottom:6px;letter-spacing:0.05em;">
          Flagged Line Items (${e.flags.length})
        </div>
        ${y}
        ${e.flags.length>5?`<div style="font-size:11px;color:#64748b;text-align:center;margin-top:4px;">+${e.flags.length-5} more — view full report in CASPER</div>`:""}
      </div>`:""}

      <!-- Risk Signals -->
      ${e.riskSignals.length>0?`
      <div style="margin-bottom:12px;">
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#475569;margin-bottom:6px;letter-spacing:0.05em;">Risk Signals</div>
        ${v}
      </div>`:""}

      <!-- Recommendation -->
      ${e.recommendation?`
      <div style="margin-bottom:14px;">
        <div style="font-size:10px;font-weight:600;text-transform:uppercase;color:#475569;margin-bottom:4px;letter-spacing:0.05em;">Recommendation</div>
        <div style="background:#0f2d1f;border:1px solid #166534;border-radius:8px;padding:8px 12px;font-size:12px;color:#86efac;line-height:1.5;">
          ${o(e.recommendation.slice(0,300))}
        </div>
      </div>`:""}

      <!-- Actions -->
      <div style="display:flex;gap:8px;">
        <button id="casper-reaudit" class="casper-btn" style="flex:1;padding:8px;background:#1e3a5f;color:#38bdf8;border:1px solid #1e4a6e;border-radius:8px;font-size:12px;font-weight:600;">
          Re-Analyze
        </button>
        <button id="casper-view-history" class="casper-btn" style="flex:1;padding:8px;background:#1e293b;color:#94a3b8;border:1px solid #334155;border-radius:8px;font-size:12px;">
          View History ↗
        </button>
      </div>
    </div>
  `,(c=t.querySelector("#casper-close-panel"))==null||c.addEventListener("click",l),(x=t.querySelector("#casper-reaudit"))==null||x.addEventListener("click",()=>p()),(f=t.querySelector("#casper-view-history"))==null||f.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_HISTORY"})})}function p(){if(!n||d)return;d=!0,R(n);const t={sourceURL:window.location.href,pageTitle:document.title,extractedText:z()};chrome.runtime.sendMessage({type:"AUDIT_PAGE",payload:t},e=>{if(d=!1,chrome.runtime.lastError){n&&g(n,"Extension context error. Try reloading the page.");return}n&&(e!=null&&e.ok&&e.data?($(n,e.data),E(e.data.riskLevel)):g(n,(e==null?void 0:e.error)??"Audit failed. Check your CASPER login in the extension options."))})}function E(t){const e=document.getElementById("casper-fab");if(!e)return;const i=t?m[t]??"#38bdf8":"#38bdf8";e.style.background=i,e.style.boxShadow=`0 4px 20px ${i}66`}function l(){n&&(a=!a,n.style.display=a?"block":"none")}function b(){if(document.getElementById("casper-fab"))return;if(!w()){const e=document.createElement("div");e.id="casper-fab",e.title="CASPER — Not a tender page",Object.assign(e.style,{position:"fixed",bottom:"16px",right:"16px",width:"44px",height:"44px",borderRadius:"50%",background:"#334155",color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"14px",fontWeight:"700",zIndex:"2147483645",cursor:"pointer",boxShadow:"0 4px 20px rgba(0,0,0,0.3)",userSelect:"none",fontFamily:"system-ui, sans-serif",letterSpacing:"-0.5px"}),e.textContent="C",document.body.appendChild(e);return}n=S(),document.body.appendChild(n);const t=document.createElement("div");t.id="casper-fab",t.title="CASPER — Click to audit this tender",Object.assign(t.style,{position:"fixed",bottom:"16px",right:"16px",height:"52px",borderRadius:"26px",background:"#38bdf8",color:"#0f172a",display:"flex",alignItems:"center",justifyContent:"center",gap:"6px",padding:"0 16px",fontSize:"13px",fontWeight:"700",zIndex:"2147483645",cursor:"pointer",boxShadow:"0 4px 20px #38bdf866",userSelect:"none",fontFamily:"system-ui, sans-serif",letterSpacing:"-0.3px",transition:"box-shadow 0.2s, transform 0.1s"}),t.innerHTML=`
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
    </svg>
    Audit Tender
  `,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.04)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)"}),t.addEventListener("click",()=>{a?l():(l(),p())}),document.body.appendChild(t)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",b):b();
})()
